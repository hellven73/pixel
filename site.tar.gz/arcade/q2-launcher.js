// Pixel Arcade local-file Qwasm2 interface. GPL-2.0.
(function(){
 const input=document.querySelector('#pakfiles'),files=document.querySelector('#files'),start=document.querySelector('#start'),status=document.querySelector('#status'),canvas=document.querySelector('#canvas'),log=document.querySelector('#log'),screen=document.querySelector('#screen'),setup=document.querySelector('#setup'),fullscreen=document.querySelector('#fullscreen');
 let selected=[],engineReady=false,loading=false,valid=false;
 const report=t=>{log.textContent=(log.textContent+String(t)+'\n').slice(-18000);log.scrollTop=log.scrollHeight;};
 function fail(e){report(e?.message||e);status.textContent='Could not start. Open Loading details below. Reload to try again.';start.disabled=true;document.querySelector('#details').open=true;}
 input.onchange=()=>{selected=[...input.files];const names=selected.map(f=>f.name.toLowerCase());valid=names.includes('pak0.pak')&&selected.every(f=>/^pak[0-9]+\.pak$/i.test(f.name))&&new Set(names).size===names.length;start.disabled=loading||(engineReady&&!valid);files.textContent=selected.map(f=>f.name+' · '+(f.size/1048576).toFixed(1)+' MB').join('\n')||'No files selected.';status.textContent=valid?'Game data selected. Files stay in your browser.':(engineReady?'Engine ready. Select your pak0.pak to play.':'Choose pak0.pak and optional numbered PAK files from your game installation.');};
 function showGame(){setup.hidden=true;screen.style.display='block';fullscreen.hidden=false;canvas.focus();}
 fullscreen.onclick=()=>screen.requestFullscreen().catch(()=>report('Fullscreen unavailable.'));
 start.onclick=async()=>{
  start.disabled=true;
  if(engineReady){
   input.disabled=true;status.textContent='Reading your local game data…';
   try{for(const file of selected){const bytes=new Uint8Array(await file.arrayBuffer());if(new TextDecoder().decode(bytes.subarray(0,4))!=='PACK')throw Error(file.name+' is not a Quake PAK archive.');FS.writeFile('/baseq2/'+file.name.toLowerCase(),bytes);}showGame();callMain(['+set','vid_renderer','soft','+set','r_mode','4']);}catch(e){fail(e);}return;
  }
  loading=true;status.textContent='Loading the engine from this site…';
  window.Module={canvas,noInitialRun:true,noExitRuntime:true,print:report,printErr:report,setStatus:t=>{if(t){status.textContent=t;report(t);}},onAbort:fail,hideConsole:showGame,showConsole:()=>{document.querySelector('#details').open=true;},winResized:()=>{},setGamma:gamma=>{canvas.style.filter=Number(gamma)>0?'brightness('+Number(gamma)*2+')':'';},captureMouse:()=>{},softExit:code=>report('Engine exited: '+code),exportFile:path=>{try{const blob=new Blob([FS.readFile(path)]);const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=path.split('/').pop();a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}catch(e){report(e.message);}},onRuntimeInitialized:()=>{engineReady=true;loading=false;start.textContent='Start Quake II';start.disabled=!valid;status.textContent=valid?'Engine ready. Start Quake II with your selected files.':'Engine ready. Select your pak0.pak to play.';report('Local WebAssembly engine initialized; waiting for your game files.');}};
  const engine=document.createElement('script');engine.src='q2-engine.js';engine.onerror=()=>fail(new Error('Local engine download failed.'));document.body.append(engine);
 };
 window.addEventListener('unhandledrejection',e=>fail(e.reason));
})();
