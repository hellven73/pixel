const paths={
 spark:'m12 3 2.6 6.4L21 12l-6.4 2.6L12 21l-2.6-6.4L3 12l6.4-2.6L12 3Z',
 user:'M20 21v-2a7 7 0 0 0-14 0v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z',
 sun:'M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8ZM12 2v2m0 16v2M2 12h2m16 0h2M5 5l1.4 1.4m11.2 11.2L19 19M5 19l1.4-1.4M17.6 6.4 19 5',
 moon:'M20.4 15.2A8.5 8.5 0 0 1 8.8 3.6 8.5 8.5 0 1 0 20.4 15.2Z',
 cover:'M3 5h18v14H3V5Zm5 6 3 3 5-5M8 22h8',exit:'M14 4h6v6m0-6-9 9M9 4H4v16h16v-5',
 study:'M4 4h6c1.3 0 2 .7 2 2v14c0-1.3-.7-2-2-2H4V4Zm16 0h-6c-1.3 0-2 .7-2 2v14c0-1.3.7-2 2-2h6V4Z',
 more:'M5 12h.01M12 12h.01M19 12h.01',menu:'M4 6h16M4 12h16M4 18h16',arrow:'M5 12h14m-5-5 5 5-5 5',out:'M8 5h11v11M19 5 5 19',
 settings:'m9.5 3-.7 2.2-2 .9-2.1-.5-2 3.4 1.5 1.8v2.4L2.7 15l2 3.4 2.1-.5 2 .9.7 2.2h4l.7-2.2 2-.9 2.1.5 2-3.4-1.5-1.8v-2.4l1.5-1.8-2-3.4-2.1.5-2-.9L13.5 3h-4ZM12 8.5a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Z',
 mail:'M3 5h18v14H3V5Zm0 1 9 7 9-7',
 help:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Zm-2-12a2 2 0 1 1 3.4 1.4c-1 .6-1.4 1-1.4 2.6m0 3h.01',
 file:'M5 3h9l5 5v13H5V3Zm9 0v6h5M8 13h8m-8 4h6',globe:'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18Z',
 game:'M7 7h10c2 0 3 2 3.5 4l1 6c.4 2-1.4 3-2.8 1.6L15 15H9l-3.7 3.6C3.9 20 2.1 19 2.5 17l1-6C4 9 5 7 7 7Zm0 3v5m-2.5-2.5h5M16 11h.01M18 14h.01',
 search:'M10.5 18a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15Zm5.5-2 5 5',play:'m9 5 11 7-11 7V5Z',invite:'M16 21v-2a6 6 0 0 0-12 0v2M10 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm9-4v6m-3-3h6',chat:'M4 4h16v13H9l-5 4V4Zm4 5h8m-8 4h5',tiles:'M3 3h7v7H3zM14 3h7v7h-7zM3 14h7v7H3zM14 14h7v7h-7z',
 pause:'M8 5v14M16 5v14',heart:'M20 5c-3-3-6-1-8 1-2-2-5-4-8-1-4 4 2 10 8 15 6-5 12-11 8-15Z'};
export function icon(name,cls='ui-glyph'){
 const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('fill','none');svg.setAttribute('stroke','currentColor');svg.setAttribute('stroke-width','1.7');svg.setAttribute('stroke-linecap','round');svg.setAttribute('stroke-linejoin','round');svg.setAttribute('aria-hidden','true');svg.classList.add(cls);const p=document.createElementNS(ns,'path');p.setAttribute('d',paths[name]||paths.spark);if(name==='more')svg.setAttribute('stroke-width','4');svg.append(p);return svg;
}
