window.gameCatalog=[];
window.gameCatalog.push({id:'webcraft-local',name:'WebCraft',cat:'Sandbox',size:'big',glyph:'▦',color:'#477443',embed:'./webcraft.html',external:false,inlineOnly:true,requiresWebGL:true,source:'Alexander Overvoorde · zlib · hosted here',help:'Open-source block-building sandbox. WASD: move; Space: jump; drag: look; left click: break; right click: place. Not an official Minecraft release.'});



window.gameCatalog.push({id:'hextris-local',name:'Hextris',cat:'Puzzle',size:'mini',glyph:'⬡',color:'#3498db',embed:'./hextris.html',external:false,inlineOnly:true,source:'Hextris · GPL-3.0 · hosted here',help:'Hosted here. Left/right arrows rotate; match three blocks of the same colour. Down speeds up falling blocks.'});
