window.gameCatalog=[];



window.gameCatalog.push({id:'hextris-local',name:'Hextris',cat:'Puzzle',size:'mini',glyph:'⬡',color:'#3498db',embed:'./hextris.html',external:false,inlineOnly:true,source:'Hextris · GPL-3.0 · hosted here',help:'Hosted here. Left/right arrows rotate; match three blocks of the same colour. Down speeds up falling blocks.'});

window.gameCatalog.push({id:'cloudmoon-brawl-stars',name:'Brawl Stars',cat:'Cloud gaming',size:'big',color:'#df9d31',embed:'https://web.cloudmoonapp.com/game/com.supercell.brawlstars/',external:true,inlineOnly:true,source:'Mobile gaming',help:'Play Brawl Stars in your browser. Requires a connection to the game service; availability and sessions depend on the service and your network.'});
