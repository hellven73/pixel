window.gameCatalog=[];



window.gameCatalog.push({id:'hextris-local',name:'Hextris',cat:'Puzzle',size:'mini',glyph:'⬡',color:'#3498db',embed:'./hextris.html',external:false,inlineOnly:true,source:'Hextris · GPL-3.0 · hosted here',help:'Hosted here. Left/right arrows rotate; match three blocks of the same colour. Down speeds up falling blocks.'});
