Source: https://github.com/Hextris/hextris
Commit: 3f4847dc8fd7dab3d1c87e6324b9159d92fbd396
Packaged 2026-11-05 for local hosting. CSS, JavaScript and required assets inlined; remote fonts, telemetry, ads and mobile metadata removed. Game logic retained. Original attribution retained. Complete source and local modifications accompany this file.
